import * as THREE from 'three';

export class Renderer extends THREE.WebGLRenderer {
  constructor() {
    super({
      canvas: document.querySelector('#canvas'),
      antialias: true,
      alpha: true,
      powerPreference: 'high-performance'
    });

    this.setSize(window.innerWidth, window.innerHeight);
    this.setPixelRatio(Math.min(window.devicePixelRatio, 2));

    this.shadowMap.enabled = true;
    this.shadowMap.type = THREE.PCFSoftShadowMap;

    this.toneMapping = THREE.ACESFilmicToneMapping;
    this.toneMappingExposure = 1.2;

    window.addEventListener('resize', () => {
      this.setSize(window.innerWidth, window.innerHeight);
      this.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    });
  }
}
