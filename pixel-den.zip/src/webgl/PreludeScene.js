import * as THREE from 'three';
import tunnelVertexShader from '../shaders/prelude/tunnelVertex.glsl?raw';
import tunnelFragmentShader from '../shaders/prelude/tunnelFragment.glsl?raw';

export class PreludeScene {
  constructor() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x000000);

    // Shader tunnel
    this.createTunnel();

    // Particle stars
    this.createStarfield();

    // Pulsing energy rings
    this.createEnergyRings();

    this.time = 0;
    this.loadingProgress = 0;
  }

  createTunnel() {
    // Cylinder geometry for tunnel
    const geometry = new THREE.CylinderGeometry(5, 5, 30, 32, 1, true);

    // Custom shader material
    const material = new THREE.ShaderMaterial({
      vertexShader: tunnelVertexShader,
      fragmentShader: tunnelFragmentShader,
      uniforms: {
        uTime: { value: 0 },
        uProgress: { value: 0 },
        uColor1: { value: new THREE.Color(0x6a5acd) }, // Purple
        uColor2: { value: new THREE.Color(0x4a90e2) }  // Blue
      },
      side: THREE.BackSide,
      transparent: true
    });

    this.tunnel = new THREE.Mesh(geometry, material);
    this.tunnel.rotation.x = Math.PI / 2;
    this.tunnel.position.z = -10;
    this.scene.add(this.tunnel);
  }

  createStarfield() {
    const geometry = new THREE.BufferGeometry();
    const positions = [];
    const colors = [];

    for (let i = 0; i < 2000; i++) {
      // Random positions
      positions.push(
        (Math.random() - 0.5) * 100,
        (Math.random() - 0.5) * 100,
        (Math.random() - 0.5) * 100
      );

      // Random colors (white to purple)
      const color = new THREE.Color();
      color.setHSL(Math.random() * 0.2 + 0.7, 0.5, 0.8);
      colors.push(color.r, color.g, color.b);
    }

    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.1,
      vertexColors: true,
      transparent: true,
      opacity: 0.8
    });

    this.stars = new THREE.Points(geometry, material);
    this.scene.add(this.stars);
  }

  createEnergyRings() {
    this.rings = [];

    for (let i = 0; i < 5; i++) {
      const geometry = new THREE.TorusGeometry(2 + i * 0.5, 0.05, 16, 100);
      const material = new THREE.MeshBasicMaterial({
        color: 0x4a90e2,
        transparent: true,
        opacity: 0.3
      });

      const ring = new THREE.Mesh(geometry, material);
      ring.position.z = -5 - i * 3;
      ring.rotation.x = Math.PI / 2;

      this.rings.push(ring);
      this.scene.add(ring);
    }
  }

  update(delta) {
    this.time += delta;

    // Update tunnel shader
    if (this.tunnel) {
      this.tunnel.material.uniforms.uTime.value = this.time;
      this.tunnel.material.uniforms.uProgress.value = this.loadingProgress;
      this.tunnel.rotation.z = this.time * 0.1;
    }

    // Rotate stars slowly
    if (this.stars) {
      this.stars.rotation.y = this.time * 0.05;
    }

    // Pulse energy rings
    this.rings.forEach((ring, index) => {
      ring.scale.setScalar(1 + Math.sin(this.time * 2 + index) * 0.1);
      ring.material.opacity = 0.3 + Math.sin(this.time * 3 + index) * 0.2;
    });
  }

  setProgress(progress) {
    this.loadingProgress = progress;
  }

  dispose() {
    // Clean up resources
    this.scene.traverse((object) => {
      if (object.geometry) object.geometry.dispose();
      if (object.material) {
        if (Array.isArray(object.material)) {
          object.material.forEach(mat => mat.dispose());
        } else {
          object.material.dispose();
        }
      }
    });
  }
}
