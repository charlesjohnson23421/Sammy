import { HeroScene } from '../scenes/HeroScene.js';
import { PortfolioScene } from '../scenes/PortfolioScene.js';
import { CertificationScene } from '../scenes/CertificationScene.js';
import { ContactScene } from '../scenes/ContactScene.js';
import { FooterScene } from '../scenes/FooterScene.js';

export class SceneManager {
  constructor(mainScene, assets) {
    this.mainScene = mainScene;
    this.assets = assets;
    this.scenes = [];
    this.currentSceneIndex = 0;

    // Initialize all scenes
    this.scenes.push(new HeroScene(mainScene, assets));
    this.scenes.push(new PortfolioScene(mainScene, assets));
    this.scenes.push(new CertificationScene(mainScene, assets));
    this.scenes.push(new ContactScene(mainScene, assets));
    this.scenes.push(new FooterScene(mainScene, assets));

    console.log('SceneManager initialized with', this.scenes.length, 'scenes');
  }

  update(scrollProgress) {
    const sceneProgress = scrollProgress * (this.scenes.length - 1);
    const currentSceneIndex = Math.floor(sceneProgress);
    const nextSceneIndex = Math.min(currentSceneIndex + 1, this.scenes.length - 1);
    const localProgress = sceneProgress - currentSceneIndex;

    // Update all scenes
    this.scenes.forEach((scene, index) => {
      if (index === currentSceneIndex || index === nextSceneIndex) {
        scene.update(localProgress, index === currentSceneIndex);
      }
    });
  }

  dispose() {
    this.scenes.forEach(scene => scene.dispose());
  }
}
