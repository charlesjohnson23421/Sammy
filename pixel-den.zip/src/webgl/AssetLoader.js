import * as THREE from 'three';
import { GLTFLoader } from 'three/examples/jsm/loaders/GLTFLoader.js';
import { DRACOLoader } from 'three/examples/jsm/loaders/DRACOLoader.js';

export class AssetLoader {
  constructor() {
    this.gltfLoader = new GLTFLoader();
    this.dracoLoader = new DRACOLoader();
    this.dracoLoader.setDecoderPath('https://www.gstatic.com/draco/versioned/decoders/1.5.6/');
    this.gltfLoader.setDRACOLoader(this.dracoLoader);

    this.manifest = {
      models: {
        hero: '/assets/hero/cloud-station.glb',
        portfolio: '/assets/portfolio/ocean-scene.glb',
        certification: '/assets/certification/space-station.glb',
        contact: '/assets/contact/universe.glb',
        footer: '/assets/footer/dancing-universe.glb'
      }
    };
  }

  async load(onProgress) {
    return new Promise((resolve, reject) => {
      const assets = { models: {} };

      const modelKeys = Object.keys(this.manifest.models);
      let loadedCount = 0;
      const totalCount = modelKeys.length;

      const checkComplete = () => {
        loadedCount++;
        onProgress(loadedCount / totalCount);

        if (loadedCount === totalCount) {
          resolve(assets);
        }
      };

      modelKeys.forEach(key => {
        const path = this.manifest.models[key];
        this.gltfLoader.load(
          path,
          (gltf) => {
            assets.models[key] = gltf;
            this.setupModel(gltf);
            checkComplete();
          },
          undefined,
          (error) => {
            console.error(`Failed to load ${key}:`, error);
            reject(error);
          }
        );
      });
    });
  }

  setupModel(gltf) {
    const model = gltf.scene;

    model.traverse((child) => {
      if (child.isMesh) {
        child.castShadow = true;
        child.receiveShadow = true;

        if (child.material) {
          child.material.envMapIntensity = 1.5;
          child.material.needsUpdate = true;
        }
      }
    });

    // Setup animations
    if (gltf.animations && gltf.animations.length > 0) {
      const mixer = new THREE.AnimationMixer(model);

      gltf.animations.forEach((clip) => {
        const action = mixer.clipAction(clip);
        action.play();
      });

      window.app.mixers.push(mixer);
    }
  }
}
