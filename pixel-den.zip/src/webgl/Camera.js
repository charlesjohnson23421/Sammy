import * as THREE from 'three';

export class Camera extends THREE.PerspectiveCamera {
  constructor() {
    super(
      75,
      window.innerWidth / window.innerHeight,
      0.1,
      10000
    );

    this.position.set(0, 0, 5);

    // Define waypoints for scrolling through scenes
    this.waypoints = [
      { position: new THREE.Vector3(0, 0, 5), lookAt: new THREE.Vector3(0, 0, 0), label: 'hero' },
      { position: new THREE.Vector3(0, -15, 8), lookAt: new THREE.Vector3(0, -15, 0), label: 'portfolio' },
      { position: new THREE.Vector3(0, -30, 10), lookAt: new THREE.Vector3(0, -30, 0), label: 'certification' },
      { position: new THREE.Vector3(0, -45, 8), lookAt: new THREE.Vector3(0, -45, 0), label: 'contact' },
      { position: new THREE.Vector3(0, -60, 5), lookAt: new THREE.Vector3(0, -60, 0), label: 'footer' }
    ];

    window.addEventListener('resize', () => {
      this.aspect = window.innerWidth / window.innerHeight;
      this.updateProjectionMatrix();
    });
  }

  update(scrollProgress) {
    const totalWaypoints = this.waypoints.length;
    const waypointIndex = scrollProgress * (totalWaypoints - 1);
    const currentWaypoint = Math.floor(waypointIndex);
    const nextWaypoint = Math.min(currentWaypoint + 1, totalWaypoints - 1);
    const lerpFactor = waypointIndex - currentWaypoint;

    const current = this.waypoints[currentWaypoint];
    const next = this.waypoints[nextWaypoint];

    // Lerp position
    this.position.lerpVectors(current.position, next.position, lerpFactor);

    // Lerp lookAt
    const targetLookAt = new THREE.Vector3().lerpVectors(current.lookAt, next.lookAt, lerpFactor);
    this.lookAt(targetLookAt);
  }
}
