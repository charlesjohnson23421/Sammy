import * as THREE from 'three';

export class HeroScene {
  constructor(mainScene, assets) {
    this.mainScene = mainScene;
    this.assets = assets;
    this.group = new THREE.Group();
    this.mainScene.add(this.group);

    this.init();
  }

  init() {
    // Hero section with cloud station model
    if (this.assets?.models?.hero) {
      const heroModel = this.assets.models.hero.scene.clone();
      heroModel.position.set(0, 0, 0);
      heroModel.scale.set(1, 1, 1);
      this.group.add(heroModel);
    } else {
      // Placeholder geometry
      const geometry = new THREE.IcosahedronGeometry(3, 4);
      const material = new THREE.MeshPhongMaterial({
        color: 0x6a5acd,
        emissive: 0x4a5f9f,
        shininess: 100
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(0, 0, 0);
      this.group.add(mesh);
    }

    // Add ambient geometry
    this.createAmbientGeometry();
  }

  createAmbientGeometry() {
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 100;
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 20;
      positions[i + 1] = (Math.random() - 0.5) * 20;
      positions[i + 2] = (Math.random() - 0.5) * 20;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0x4a90e2,
      size: 0.1,
      transparent: true,
      opacity: 0.5
    });

    this.particles = new THREE.Points(particleGeometry, material);
    this.group.add(this.particles);
  }

  update(progress, isActive) {
    if (this.group) {
      this.group.rotation.y += 0.002;
      this.group.position.y = 0;
    }
    if (this.particles) {
      this.particles.rotation.z += 0.0005;
    }
  }

  dispose() {
    this.group.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) {
          child.material.forEach(mat => mat.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
    this.mainScene.remove(this.group);
  }
}
