import * as THREE from 'three';

export class FooterScene {
  constructor(mainScene, assets) {
    this.mainScene = mainScene;
    this.assets = assets;
    this.group = new THREE.Group();
    this.mainScene.add(this.group);

    this.init();
  }

  init() {
    // Footer section with dancing universe model
    if (this.assets?.models?.footer) {
      const footerModel = this.assets.models.footer.scene.clone();
      footerModel.position.set(0, -60, 0);
      footerModel.scale.set(1, 1, 1);
      this.group.add(footerModel);
    } else {
      // Placeholder geometry
      const geometry = new THREE.SphereGeometry(3, 32, 32);
      const material = new THREE.MeshPhongMaterial({
        color: 0xd94ae2,
        emissive: 0x8f2a8f,
        shininess: 100
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(0, -60, 0);
      this.group.add(mesh);
    }

    this.createAmbientGeometry();
  }

  createAmbientGeometry() {
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 180;
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 26;
      positions[i + 1] = -60 + (Math.random() - 0.5) * 22;
      positions[i + 2] = (Math.random() - 0.5) * 26;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0xe24ad9,
      size: 0.15,
      transparent: true,
      opacity: 0.6
    });

    this.particles = new THREE.Points(particleGeometry, material);
    this.group.add(this.particles);
  }

  update(progress, isActive) {
    if (this.group) {
      this.group.rotation.y -= 0.002;
      this.group.position.y = -60;
    }
    if (this.particles) {
      this.particles.rotation.z -= 0.0003;
    }
  }

  dispose() {
    this.group.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) {
          child.material.forEach(mat => mat.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
    this.mainScene.remove(this.group);
  }
}
