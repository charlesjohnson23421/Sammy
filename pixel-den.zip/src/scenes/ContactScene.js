import * as THREE from 'three';

export class ContactScene {
  constructor(mainScene, assets) {
    this.mainScene = mainScene;
    this.assets = assets;
    this.group = new THREE.Group();
    this.mainScene.add(this.group);

    this.init();
  }

  init() {
    // Contact section with universe model
    if (this.assets?.models?.contact) {
      const contactModel = this.assets.models.contact.scene.clone();
      contactModel.position.set(0, -45, 0);
      contactModel.scale.set(1, 1, 1);
      this.group.add(contactModel);
    } else {
      // Placeholder geometry
      const geometry = new THREE.DodecahedronGeometry(2.5, 2);
      const material = new THREE.MeshPhongMaterial({
        color: 0x4ae2d9,
        emissive: 0x2a8f8f,
        shininess: 100
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(0, -45, 0);
      this.group.add(mesh);
    }

    this.createAmbientGeometry();
  }

  createAmbientGeometry() {
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 140;
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 24;
      positions[i + 1] = -45 + (Math.random() - 0.5) * 20;
      positions[i + 2] = (Math.random() - 0.5) * 24;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0x4ad9e2,
      size: 0.13,
      transparent: true,
      opacity: 0.5
    });

    this.particles = new THREE.Points(particleGeometry, material);
    this.group.add(this.particles);
  }

  update(progress, isActive) {
    if (this.group) {
      this.group.rotation.z += 0.0015;
      this.group.position.y = -45;
    }
    if (this.particles) {
      this.particles.rotation.x -= 0.0005;
    }
  }

  dispose() {
    this.group.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) {
          child.material.forEach(mat => mat.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
    this.mainScene.remove(this.group);
  }
}
