import * as THREE from 'three';

export class PortfolioScene {
  constructor(mainScene, assets) {
    this.mainScene = mainScene;
    this.assets = assets;
    this.group = new THREE.Group();
    this.mainScene.add(this.group);

    this.init();
  }

  init() {
    // Portfolio section with ocean scene model
    if (this.assets?.models?.portfolio) {
      const portfolioModel = this.assets.models.portfolio.scene.clone();
      portfolioModel.position.set(0, -15, 0);
      portfolioModel.scale.set(1, 1, 1);
      this.group.add(portfolioModel);
    } else {
      // Placeholder geometry
      const geometry = new THREE.OctahedronGeometry(3, 3);
      const material = new THREE.MeshPhongMaterial({
        color: 0x4a90e2,
        emissive: 0x2a5f7f,
        shininess: 100
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(0, -15, 0);
      this.group.add(mesh);
    }

    this.createAmbientGeometry();
  }

  createAmbientGeometry() {
    const particleGeometry = new THREE.BufferGeometry();
    const particleCount = 150;
    const positions = new Float32Array(particleCount * 3);

    for (let i = 0; i < particleCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 25;
      positions[i + 1] = -15 + (Math.random() - 0.5) * 20;
      positions[i + 2] = (Math.random() - 0.5) * 25;
    }

    particleGeometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({
      color: 0x90d4e2,
      size: 0.12,
      transparent: true,
      opacity: 0.4
    });

    this.particles = new THREE.Points(particleGeometry, material);
    this.group.add(this.particles);
  }

  update(progress, isActive) {
    if (this.group) {
      this.group.rotation.z += 0.001;
      this.group.position.y = -15;
    }
    if (this.particles) {
      this.particles.rotation.x += 0.0003;
    }
  }

  dispose() {
    this.group.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) {
          child.material.forEach(mat => mat.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
    this.mainScene.remove(this.group);
  }
}
