import './style.css';
import * as THREE from 'three';
import { PreludeScene } from './webgl/PreludeScene.js';
import { Scene } from './webgl/Scene.js';
import { Camera } from './webgl/Camera.js';
import { Renderer } from './webgl/Renderer.js';
import { AssetLoader } from './webgl/AssetLoader.js';
import { SceneManager } from './webgl/SceneManager.js';
import Lenis from 'lenis';
import gsap from 'gsap';

// Global app state
window.app = {
  phase: 'prelude',
  preludeScene: null,
  mainScene: null,
  camera: null,
  renderer: null,
  sceneManager: null,
  lenis: null,
  mixers: [],
  clock: new THREE.Clock(),
  assets: null
};

// =====================
// PHASE 1: PRELUDE
// =====================

function initPrelude() {
  console.log('🌌 Initializing Prelude...');

  window.app.renderer = new Renderer();
  window.app.preludeScene = new PreludeScene();

  window.app.camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  );
  window.app.camera.position.set(0, 0, 5);

  document.querySelector('#prelude-ui').style.display = 'flex';
  document.querySelector('#main-content').style.display = 'none';

  animatePrelude();
  loadAssets();
}

function animatePrelude() {
  if (window.app.phase !== 'prelude') return;

  requestAnimationFrame(animatePrelude);

  const delta = window.app.clock.getDelta();
  window.app.preludeScene.update(delta);
  window.app.renderer.render(window.app.preludeScene.scene, window.app.camera);
}

// =====================
// ASSET LOADING
// =====================

async function loadAssets() {
  const assetLoader = new AssetLoader();

  try {
    const assets = await assetLoader.load((progress) => {
      const percent = Math.round(progress * 100);
      document.querySelector('#loading-progress').textContent = `${percent}%`;
      document.querySelector('#loading-bar-fill').style.width = `${percent}%`;
      window.app.preludeScene.setProgress(progress);
    });

    window.app.assets = assets;
    console.log('✅ All assets loaded:', assets);
    showEnterButton();
  } catch (error) {
    console.error('❌ Asset loading failed:', error);
    document.querySelector('#loading-text').textContent = 'Loading failed. Please refresh.';
  }
}

function showEnterButton() {
  const loadingText = document.querySelector('#loading-text');
  const progressContainer = document.querySelector('#progress-container');
  const enterButton = document.querySelector('#enter-button');

  gsap.to([loadingText, progressContainer], {
    opacity: 0,
    duration: 0.5,
    onComplete: () => {
      loadingText.style.display = 'none';
      progressContainer.style.display = 'none';
    }
  });

  gsap.to(enterButton, {
    opacity: 1,
    duration: 0.8,
    delay: 0.3,
    ease: 'power2.out'
  });

  enterButton.addEventListener('click', enterMainExperience);
}

// =====================
// PHASE 2: MAIN EXPERIENCE
// =====================

function enterMainExperience() {
  console.log('🚀 Entering main experience...');

  const enterButton = document.querySelector('#enter-button');

  gsap.to(enterButton, {
    scale: 1.2,
    opacity: 0,
    duration: 0.4
  });

  gsap.timeline()
    .to(window.app.camera.position, {
      z: -50,
      duration: 2,
      ease: 'power2.inOut'
    })
    .to('#prelude-ui', {
      opacity: 0,
      duration: 1,
      onComplete: () => {
        window.app.phase = 'main';
        initMainExperience();
      }
    }, '-=0.5');
}

function initMainExperience() {
  document.querySelector('#prelude-ui').style.display = 'none';
  document.querySelector('#main-content').style.display = 'block';

  window.app.preludeScene.dispose();
  window.app.preludeScene = null;

  window.app.mainScene = new Scene();
  window.app.camera = new Camera();
  window.app.sceneManager = new SceneManager(window.app.mainScene, window.app.assets);

  window.app.lenis = new Lenis({
    duration: 1.2,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smooth: true,
    smoothTouch: false
  });

  function raf(time) {
    window.app.lenis.raf(time);
    requestAnimationFrame(raf);
  }
  requestAnimationFrame(raf);

  animateMain();
}

function animateMain() {
  requestAnimationFrame(animateMain);

  const delta = window.app.clock.getDelta();
  const scrollProgress = window.app.lenis?.progress || 0;

  window.app.camera.update(scrollProgress);
  window.app.sceneManager.update(scrollProgress);
  window.app.mixers.forEach(mixer => mixer.update(delta));

  window.app.renderer.render(window.app.mainScene, window.app.camera);
}

// START
initPrelude();
