import * as THREE from 'three';

export class PortfolioScene {
  constructor(mainScene, assets) {
    this.mainScene = mainScene;
    this.assets = assets;
    this.group = new THREE.Group();
    this.mainScene.add(this.group);
    this.init();
  }

  init() {
    if (this.assets?.models?.portfolio) {
      const model = this.assets.models.portfolio.scene.clone();
      model.position.set(0, -15, 0);
      this.group.add(model);
    } else {
      const geometry = new THREE.OctahedronGeometry(3, 3);
      const material = new THREE.MeshPhongMaterial({
        color: 0x4a90e2,
        emissive: 0x2a5f7f,
        shininess: 100
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(0, -15, 0);
      this.group.add(mesh);
    }
    this.createParticles();
  }

  createParticles() {
    const positions = new Float32Array(450);
    for (let i = 0; i < positions.length; i += 3) {
      positions[i] = (Math.random() - 0.5) * 25;
      positions[i + 1] = -15 + (Math.random() - 0.5) * 20;
      positions[i + 2] = (Math.random() - 0.5) * 25;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({ color: 0x90d4e2, size: 0.18, transparent: true, opacity: 0.5 });
    this.particles = new THREE.Points(geometry, material);
    this.group.add(this.particles);
  }

  update(progress, isActive) {
    if (this.group) {
      this.group.rotation.z += 0.001;
    }
    if (this.particles) {
      this.particles.rotation.x += 0.0003;
    }
  }

  dispose() {
    this.group.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) {
          child.material.forEach(mat => mat.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
    this.mainScene.remove(this.group);
  }
}
