import * as THREE from 'three';

export class FooterScene {
  constructor(mainScene, assets) {
    this.mainScene = mainScene;
    this.assets = assets;
    this.group = new THREE.Group();
    this.mainScene.add(this.group);
    this.init();
  }

  init() {
    if (this.assets?.models?.footer) {
      const model = this.assets.models.footer.scene.clone();
      model.position.set(0, -60, 0);
      this.group.add(model);
    } else {
      const geometry = new THREE.SphereGeometry(3, 32, 32);
      const material = new THREE.MeshPhongMaterial({
        color: 0xd94ae2,
        emissive: 0x8f2a8f,
        shininess: 100
      });
      const mesh = new THREE.Mesh(geometry, material);
      mesh.position.set(0, -60, 0);
      this.group.add(mesh);
    }
    this.createParticles();
  }

  createParticles() {
    const positions = new Float32Array(540);
    for (let i = 0; i < positions.length; i += 3) {
      positions[i] = (Math.random() - 0.5) * 26;
      positions[i + 1] = -60 + (Math.random() - 0.5) * 22;
      positions[i + 2] = (Math.random() - 0.5) * 26;
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const material = new THREE.PointsMaterial({ color: 0xe24ad9, size: 0.22, transparent: true, opacity: 0.65 });
    this.particles = new THREE.Points(geometry, material);
    this.group.add(this.particles);
  }

  update(progress, isActive) {
    if (this.group) {
      this.group.rotation.y -= 0.002;
    }
    if (this.particles) {
      this.particles.rotation.z -= 0.0003;
    }
  }

  dispose() {
    this.group.traverse((child) => {
      if (child.geometry) child.geometry.dispose();
      if (child.material) {
        if (Array.isArray(child.material)) {
          child.material.forEach(mat => mat.dispose());
        } else {
          child.material.dispose();
        }
      }
    });
    this.mainScene.remove(this.group);
  }
}
