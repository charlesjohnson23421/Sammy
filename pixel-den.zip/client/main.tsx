import './global.css';
import * as THREE from 'three';
import { PreludeScene } from './webgl/PreludeScene.js';
import { Scene } from './webgl/Scene.js';
import { Camera } from './webgl/Camera.js';
import { Renderer } from './webgl/Renderer.js';
import { AssetLoader } from './webgl/AssetLoader.js';
import { SceneManager } from './webgl/SceneManager.js';
import Lenis from 'lenis';
import gsap from 'gsap';

// Global app state
window.app = {
  phase: 'prelude', // 'prelude' or 'main'
  preludeScene: null,
  mainScene: null,
  camera: null,
  renderer: null,
  sceneManager: null,
  lenis: null,
  mixers: [],
  clock: new THREE.Clock(),
  assets: null
};

// ======================
// PHASE 1: PRELUDE
// ======================

function initPrelude() {
  console.log('🌌 Initializing Prelude...');

  // Setup renderer
  window.app.renderer = new Renderer();

  // Create prelude scene
  window.app.preludeScene = new PreludeScene();

  // Prelude camera (static, looking at tunnel)
  window.app.camera = new THREE.PerspectiveCamera(
    75,
    window.innerWidth / window.innerHeight,
    0.1,
    1000
  );
  window.app.camera.position.set(0, 0, 5);

  // Show prelude UI
  document.querySelector('#prelude-ui').style.display = 'flex';
  document.querySelector('#main-content').style.display = 'none';

  // Start prelude animation loop
  animatePrelude();

  // Start loading assets
  loadAssets();
}

function animatePrelude() {
  if (window.app.phase !== 'prelude') return;

  requestAnimationFrame(animatePrelude);

  const delta = window.app.clock.getDelta();

  // Update prelude scene (tunnel animation)
  window.app.preludeScene.update(delta);

  // Render
  window.app.renderer.render(
    window.app.preludeScene.scene,
    window.app.camera
  );
}

// ======================
// ASSET LOADING
// ======================

async function loadAssets() {
  const assetLoader = new AssetLoader();

  try {
    const assets = await assetLoader.load((progress) => {
      // Update progress UI
      const percent = Math.round(progress * 100);
      document.querySelector('#loading-progress').textContent = `${percent}%`;
      document.querySelector('#loading-bar-fill').style.width = `${percent}%`;

      // Update prelude scene progress (affects tunnel animation)
      window.app.preludeScene.setProgress(progress);
    });

    window.app.assets = assets;
    console.log('✅ All assets loaded:', assets);

    // Show enter button
    showEnterButton();
  } catch (error) {
    console.error('❌ Asset loading failed:', error);
    document.querySelector('#loading-text').textContent = 'Loading failed. Please refresh.';
  }
}

function showEnterButton() {
  const loadingText = document.querySelector('#loading-text');
  const progressContainer = document.querySelector('#progress-container');
  const enterButton = document.querySelector('#enter-button');

  // Fade out loading UI
  gsap.to([loadingText, progressContainer], {
    opacity: 0,
    duration: 0.5,
    onComplete: () => {
      loadingText.style.display = 'none';
      progressContainer.style.display = 'none';
    }
  });

  // Fade in enter button
  gsap.to(enterButton, {
    opacity: 1,
    duration: 0.8,
    delay: 0.3,
    ease: 'power2.out'
  });

  // Click handler
  enterButton.addEventListener('click', enterMainExperience);
}

// ======================
// PHASE 2: MAIN EXPERIENCE
// ======================

function enterMainExperience() {
  console.log('🚀 Entering main experience...');

  const enterButton = document.querySelector('#enter-button');

  // Animate button out
  gsap.to(enterButton, {
    scale: 1.2,
    opacity: 0,
    duration: 0.4
  });

  // Transition sequence
  gsap.timeline()
    .to(window.app.camera.position, {
      z: -50,
      duration: 2,
      ease: 'power2.inOut'
    })
    .to('#prelude-ui', {
      opacity: 0,
      duration: 1,
      onComplete: () => {
        // Switch to main phase
        window.app.phase = 'main';
        initMainExperience();
      }
    }, '-=0.5');
}

function initMainExperience() {
  // Hide prelude UI
  document.querySelector('#prelude-ui').style.display = 'none';
  document.querySelector('#main-content').style.display = 'block';

  // Dispose prelude scene
  window.app.preludeScene.dispose();
  window.app.preludeScene = null;

  // Create main scene
  window.app.mainScene = new Scene();

  // Create main camera (with waypoints)
  window.app.camera = new Camera();

  // Initialize scene manager with all 5 scenes
  window.app.sceneManager = new SceneManager(
    window.app.mainScene,
    window.app.assets
  );

  // Setup smooth scroll
  window.app.lenis = new Lenis({
    duration: 1.2,
    easing: (t) => Math.min(1, 1.001 - Math.pow(2, -10 * t)),
    smooth: true,
    smoothTouch: false
  });

  function raf(time) {
    window.app.lenis.raf(time);
    requestAnimationFrame(raf);
  }
  requestAnimationFrame(raf);

  // Start main animation loop
  animateMain();
}

function animateMain() {
  requestAnimationFrame(animateMain);

  const delta = window.app.clock.getDelta();
  const scrollProgress = window.app.lenis?.progress || 0;

  // Update camera
  window.app.camera.update(scrollProgress);

  // Update scene manager
  window.app.sceneManager.update(scrollProgress);

  // Update GLB animations
  window.app.mixers.forEach(mixer => mixer.update(delta));

  // Render
  window.app.renderer.render(window.app.mainScene, window.app.camera);
}

// ======================
// START
// ======================

initPrelude();
