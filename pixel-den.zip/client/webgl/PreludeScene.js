import * as THREE from 'three';

export class PreludeScene {
  constructor() {
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x000000);

    // Lighting
    const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
    this.scene.add(ambientLight);

    const pointLight = new THREE.PointLight(0x6a5acd, 2, 200);
    pointLight.position.set(0, 10, 20);
    this.scene.add(pointLight);

    this.createTunnel();
    this.createStarfield();
    this.createEnergyRings();

    this.time = 0;
    this.loadingProgress = 0;
  }

  createTunnel() {
    const geometry = new THREE.CylinderGeometry(6, 6, 40, 32, 1, true);
    const material = new THREE.MeshPhongMaterial({
      color: 0x6a5acd,
      emissive: 0x4a5acd,
      wireframe: false,
      transparent: true,
      opacity: 0.4
    });

    this.tunnel = new THREE.Mesh(geometry, material);
    this.tunnel.rotation.x = Math.PI / 2;
    this.tunnel.position.z = -15;
    this.scene.add(this.tunnel);
  }

  createStarfield() {
    const positions = [];
    const colors = [];

    for (let i = 0; i < 500; i++) {
      const radius = 15 + Math.random() * 50;
      const theta = Math.random() * Math.PI * 2;
      const phi = Math.random() * Math.PI;

      positions.push(
        radius * Math.sin(phi) * Math.cos(theta),
        radius * Math.sin(phi) * Math.sin(theta),
        radius * Math.cos(phi)
      );

      const brightness = 0.5 + Math.random() * 0.5;
      colors.push(brightness, brightness, brightness);
    }

    const geometry = new THREE.BufferGeometry();
    geometry.setAttribute('position', new THREE.Float32BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));

    const material = new THREE.PointsMaterial({
      size: 0.4,
      vertexColors: true,
      transparent: true,
      opacity: 0.9,
      sizeAttenuation: true
    });

    this.stars = new THREE.Points(geometry, material);
    this.scene.add(this.stars);
  }

  createEnergyRings() {
    this.rings = [];
    const colors = [0x4a90e2, 0x6a5acd, 0x9d4edd, 0xc77dff, 0xe0aaff];

    for (let i = 0; i < 5; i++) {
      const geometry = new THREE.TorusGeometry(3 + i * 1, 0.2, 16, 100);
      const material = new THREE.MeshPhongMaterial({
        color: colors[i],
        emissive: colors[i],
        emissiveIntensity: 0.4,
        transparent: true,
        opacity: 0.7
      });

      const ring = new THREE.Mesh(geometry, material);
      ring.position.z = -2 - i * 2;
      ring.rotation.x = Math.PI / 2;

      this.rings.push(ring);
      this.scene.add(ring);
    }
  }

  update(delta) {
    this.time += delta;

    if (this.tunnel) {
      this.tunnel.rotation.z = this.time * 0.15;
      this.tunnel.material.opacity = 0.3 + Math.sin(this.time * 2) * 0.15;
    }

    if (this.stars) {
      this.stars.rotation.y = this.time * 0.02;
      this.stars.rotation.z = this.time * 0.01;
    }

    this.rings.forEach((ring, index) => {
      ring.rotation.z += 0.01 * (index % 2 === 0 ? 1 : -1);
      const scale = 1 + Math.sin(this.time * 2 + index) * 0.15;
      ring.scale.setScalar(scale);
      ring.material.opacity = 0.5 + Math.sin(this.time * 3 + index) * 0.25;
    });
  }

  setProgress(progress) {
    this.loadingProgress = progress;
  }

  dispose() {
    this.scene.traverse((object) => {
      if (object.geometry) object.geometry.dispose();
      if (object.material) {
        if (Array.isArray(object.material)) {
          object.material.forEach(mat => mat.dispose());
        } else {
          object.material.dispose();
        }
      }
    });
  }
}
