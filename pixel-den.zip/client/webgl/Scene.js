import * as THREE from 'three';

export class Scene extends THREE.Scene {
  constructor() {
    super();
    this.background = new THREE.Color(0x000011);
    this.fog = new THREE.Fog(0x000011, 0, 500);

    const ambientLight = new THREE.AmbientLight(0xffffff, 0.6);
    this.add(ambientLight);

    const directionalLight = new THREE.DirectionalLight(0xffffff, 1);
    directionalLight.position.set(10, 20, 10);
    directionalLight.castShadow = true;
    directionalLight.shadow.mapSize.width = 2048;
    directionalLight.shadow.mapSize.height = 2048;
    this.add(directionalLight);

    const pointLight = new THREE.PointLight(0x6a5acd, 1, 100);
    pointLight.position.set(0, 20, 0);
    this.add(pointLight);
  }
}
