import * as THREE from 'three';

export class ProceduralGeometry {
  static createTerrain(width = 100, height = 100, segments = 32) {
    const geometry = new THREE.PlaneGeometry(width, height, segments, segments);
    const positions = geometry.attributes.position.array;

    // Apply noise-like displacement
    for (let i = 0; i < positions.length; i += 3) {
      const x = positions[i];
      const y = positions[i + 1];
      const displacement = Math.sin(x * 0.1) * Math.cos(y * 0.1) * 5;
      positions[i + 2] += displacement;
    }

    geometry.attributes.position.needsUpdate = true;
    geometry.computeVertexNormals();
    return geometry;
  }

  static createWaveForm(segments = 64) {
    const geometry = new THREE.BufferGeometry();
    const positions = [];
    const indices = [];

    for (let i = 0; i <= segments; i++) {
      const x = (i / segments) * Math.PI * 2;
      const y = Math.sin(x) * 2;
      positions.push(x - Math.PI, y, 0);
    }

    for (let i = 0; i < segments; i++) {
      indices.push(i, i + 1);
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(new Float32Array(positions), 3));
    geometry.setIndex(new THREE.BufferAttribute(new Uint16Array(indices), 1));

    return geometry;
  }

  static createParticleSystem(count = 1000, range = 100) {
    const geometry = new THREE.BufferGeometry();
    const positions = new Float32Array(count * 3);
    const colors = new Float32Array(count * 3);

    for (let i = 0; i < count * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * range;
      positions[i + 1] = (Math.random() - 0.5) * range;
      positions[i + 2] = (Math.random() - 0.5) * range;

      colors[i] = Math.random();
      colors[i + 1] = Math.random();
      colors[i + 2] = Math.random();
    }

    geometry.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    geometry.setAttribute('color', new THREE.BufferAttribute(colors, 3));

    return geometry;
  }
}
